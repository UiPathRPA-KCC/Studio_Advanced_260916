using UiPath.CodedWorkflows;
using System;

namespace Day2_260917
{
    public class ConnectionsManager
    {
        public ConnectionsManager(ICodedWorkflowsServiceContainer resolver)
        {
        }
    }
}